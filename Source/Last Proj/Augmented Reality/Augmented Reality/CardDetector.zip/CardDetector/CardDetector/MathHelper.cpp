#include "stdafx.h"
#include "MathHelper.h"

CMathHelper::CMathHelper(void)
{
}

CMathHelper::~CMathHelper(void)
{
}
